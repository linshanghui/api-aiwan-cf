### Hi there 👋

<!--
**cnm-sb/cnm-sb** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

一款比较不错的个人主页开源代码仓库<br>


安装教程<br>
直接上传压缩包解压就完事了，只有前端，没有后台，大佬如果需要，可以自行添加后台。

修改说明<br>
就这样那样，就完事了,代码注释写的很全，官网也有一些修改指引。

官方演示<br>
https://cnm.sb

版权所有<br>
CNMSB摸鱼工作室版权所有，转载还请保留版权信息。<br><br>
github开源地址：https://github.com/cnm-sb/cnm-sb<br>
gitee开源地址：https://gitee.com/cnm-sb/cnm-sb
